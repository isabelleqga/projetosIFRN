/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Isabelle
 */
public class GerarSenhaAlfabetica implements GeradorSenha {
    
     public String gerar() {
        Random random = new Random();
        String[] letras = new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
				"N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a",
				"b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
				"p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        String senha = "";
        for (int i = 0; i < letras.length; i++) {
                int a = random.nextInt(52);
		senha +=(letras[a]);
	}
        return senha;
    }

    
}

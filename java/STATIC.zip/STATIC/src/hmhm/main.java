/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmhm;

/**
 *
 * @author Isabelle
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conta a, b, c;
        a = new Conta();
        b = new Conta();
        c = new Conta();
        c.zerarcontador();

        Funcionario f = new Funcionario("Seneca", "5785", 200);
        Funcionario g = new Funcionario("Epícuro", "2564", 10);
    }

}

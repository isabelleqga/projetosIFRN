/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmhm;

/**
 *
 * @author Isabelle
 */
public class Funcionario {

    private String nome;
    private String cadastro;
    private double salario;
    public static double pisosalarial;
    public static double taxa = 325;

    public Funcionario(String nome, String cadastro, double salario) {
        this.nome = nome;
        this.cadastro = cadastro;
        this.salario = salario;
        reajustar();
        System.out.print("\nFuncionario: " + nome + "\nCadastro: " + cadastro + "\nSalario: R$" + salario + "\nValidez: ");
        checar();

    }

    public void checar() {
        if (this.salario < this.pisosalarial) {
            System.out.print("Deu mal hein\n");
        } else {
            System.out.print("De boa meu consagrado\n");
        }
    }

    public void reajustar() {
        this.pisosalarial = this.taxa * 0.5;
    }

}

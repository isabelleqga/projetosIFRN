/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmhm;

import java.util.Random;

public class Conta {

    private String numerodaconta;
    public static int continst = 0;
    Random random = new Random();

    public Conta() {
        this.continst += 1;
        this.numerodaconta = "" + gerarnumero();
        System.out.println("Numero da conta: " + numerodaconta);
    }

    public String gerarnumero() {
        String[] letrasenumeros = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9",
            "0"};
        String senha = "";
        for (int i = 0; i < 8; i++) {
            int a = random.nextInt(9);
            senha += (letrasenumeros[a]);
        }
        return senha;
    }

    public void zerarcontador() {
        System.out.println("Numero de contas criadas: " + continst);
        this.continst = 0;
        System.out.println("Zerar: " + continst);
    }

}


package supermercado;

public abstract class Pedidos {
    private String item;
    private String quantidadeI;  
    protected abstract void modoPagar();

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getQuantidadeI() {
        return quantidadeI;
    }

    public void setQuantidadeI(String quantidadeI) {
        this.quantidadeI = quantidadeI;
    }
}


package supermercado;

public class Produtos {
    private String nome;
    private double preço;
    private int quantidadeEstoque;
    
    
}

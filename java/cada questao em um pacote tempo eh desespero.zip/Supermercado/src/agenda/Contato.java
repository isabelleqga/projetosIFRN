/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda;

/**
 *
 * @author Isabelle
 */
public class Contato {
    private String nome;
    private String numero;
    
    public void adicionar(String nome, String numero){
        this.nome = nome;
        this.numero = numero;
    }
    
    public void mostrarInfo(){
        System.out.print("Nome: "+this.nome+"\nNumero: "+this.numero+"\n\n");
    }
}

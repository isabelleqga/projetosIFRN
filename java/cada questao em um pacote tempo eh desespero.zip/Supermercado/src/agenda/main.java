/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda;

import static agenda.Agenda.contatos;
import java.util.ArrayList;

/**
 *
 * @author Isabelle
 */
public class main {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        Contato c1, c2, c3;
        
        contatos = new ArrayList<>();
        
        c1 = new Contato();
        c2 = new Contato();
        c3 = new Contato();
        c1.adicionar("Dany","99457-4592");
        c2.adicionar("Ywry","99256-2455");
        c3.adicionar("Guga","99821-2542");
        contatos.add(c1);
        contatos.add(c2);
        contatos.add(c3);
        
        c1.mostrarInfo();
        c2.mostrarInfo();
        c3.mostrarInfo();}
    
}

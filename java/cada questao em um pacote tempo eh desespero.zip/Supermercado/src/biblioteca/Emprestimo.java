/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

/**
 *
 * @author Isabelle
 */
public class Emprestimo {
    private Livro livro;
    private Pessoa usuario;
    private int tempoPego;
    
    public void emprestimo(){
        livro.getCodigo();
        if (livro.isDisponivel()){
            livro.setDisponivel(false);
        }else{
            System.out.println("O livro não está disponível");
    }
        
    }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public Pessoa getUsuario() {
        return usuario;
    }

    public void setUsuario(Pessoa usuario) {
        this.usuario = usuario;
    }
    
}

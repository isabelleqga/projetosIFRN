
package area;

public abstract class Forma {
    public double altura;
    public double base;
    
    public Forma(double altura, double base){
        this.altura = altura;
        this.base = base;
    }
    
    public abstract void mostrarArea();

    
}


package area;

public class Quadrilatero extends Forma{
   
    private double area;
    
    public Quadrilatero(double altura, double base) {
        super(altura, base);
        this.area = altura*base;    
    }
    public void mostrarArea(){
        System.out.println("Área do quadrilátero: "+this.area);
    }

        
}

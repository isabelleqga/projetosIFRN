/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package area;

/**
 *
 * @author Isabelle
 */
public class programa {

    public static void main(String[] args) {
        Forma q, c, t, r;
        q = new Quadrilatero(2,2);
        q.mostrarArea();
        r = new Quadrilatero(2,6);
        r.mostrarArea();
        c = new Circulo(5,3);
        c.mostrarArea();
        t = new Triangulo(5,5);
        t.mostrarArea();

    }
    
}

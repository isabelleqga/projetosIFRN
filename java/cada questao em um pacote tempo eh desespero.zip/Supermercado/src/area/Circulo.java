/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package area;

/**
 *
 * @author Isabelle
 */
public class Circulo extends Forma{
    private double area;
    public Circulo(double altura, double base) {
        super(altura, base);
        double aoquad = (this.altura/2)*(this.altura/2); //faz o raio
        this.area = aoquad*3.14;
        
    }
    public void mostrarArea(){
        System.out.println("Área do círculo: "+this.area);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package area;

/**
 *
 * @author Isabelle
 */
public class Triangulo extends Forma{
    
    private double area;
    public Triangulo(double altura, double base) {
        super(altura, base);
        this.area = base*altura/2;
    }

    public void mostrarArea(){
        System.out.println("Área do triângulo: "+this.area);
    }

   


}

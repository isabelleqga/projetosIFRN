/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofcof;

/**
 *
 * @author Isabelle
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario a,b;
        a= new Funcionario();
        b= new Funcionario();
        a.setNome("Estian");
        a.setSalario(112536);
        System.out.print("\nFuncionario: " + a.getNome() + "\nSalario: R$" + a.getSalario()+"\n");
        
        b.setNome("Osvaldo");
        b.setSalario(11234);
        System.out.print("\nFuncionario: " + b.getNome() + "\nSalario: R$" + b.getSalario()+"\n");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaaaaa;

/**
 *
 * @author Isabelle
 */
public class Telefonista extends Funcionario{
    private String codigo;

    Telefonista(String bbb) {
        this.codigo = bbb;
    }
    public void mostrarDados(){
       super.mostrarDados();
       System.out.println("\nCodigo: "+codigo);
    }

}

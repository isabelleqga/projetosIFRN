/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaaaaa;

/**
 *
 * @author Isabelle
 */
public class Secretarias extends Funcionario{
    private String ramal;

    Secretarias(String ramal) {
        this.ramal = ramal;
    }

    public void mostrarDados(){
       super.mostrarDados();
       System.out.println("\nRamal:" + ramal);
    }

 
}

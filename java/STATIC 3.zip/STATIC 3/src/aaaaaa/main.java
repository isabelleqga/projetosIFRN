/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaaaaa;

/**
 *
 * @author Isabelle
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario a, b, c;
        a = new Gerente("EuSouArnalso","QuicaQuica");
        b = new Telefonista("89189");
        c = new Secretarias("1212");
        
        a.setNome("Ardilson");
        a.setSalario(100);
        
        b.setNome("Bolinha");
        b.setSalario(100);
        
        c.setNome("Carlos");
        c.setSalario(100);
        
        a.mostrarDados();
        b.mostrarDados();
        c.mostrarDados();
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaaaaa;

/**
 *
 * @author Isabelle
 */
public class Gerente extends Funcionario{
    private String user;
    private String senha;

    Gerente(String user, String senha) {
        this.user = user;
        this.senha = senha;
    }
   
    public void bonificacao() {
        this.salario += this.salario*50/100;
    }
    
    public void mostrarDados(){
       super.mostrarDados();
       System.out.println("\nUsuário:" + user + "\nSenha: " + senha);
    }

}

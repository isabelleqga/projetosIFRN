/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Isabelle
 */
public class Flou implements Lampada{
    
    public String ligar() {
        return "Flourescente ligada ";
    }
    public String desligar() {
        return "Flourescente desligada ";
    }
    
}

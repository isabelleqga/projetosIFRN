/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Isabelle
 */
public class Incan implements Lampada{
    public String ligar() {
        return "Incandescente ligada ";
    }
    public String desligar() {
        return "Incandescente desligada ";
    }
    
}


package classes;


public interface Lampada {
    String ligar();
    String desligar();
    
}

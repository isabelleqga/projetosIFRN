/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a;

import java.util.Scanner;

/**
 *
 * @author Isabelle
 */
public class numerosprimos {

    static int n;
    static int v[] = new int[100];

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite um n maior que 0: ");
        n = sc.nextInt();

        new Thread(t1).start();
        new Thread(t2).start();

    }

    private static void mostrar() {
        for (int b = 0; b <= v.length; b++) {
            System.out.println(v[b]);
        }
    }

    private static Runnable t1 = new Runnable() {
        public synchronized void run() {
            int a = 0;
            int contar = 0;
            for (int k = 1; k < n/2; k++) {
                if (n % k == 0) {
                    ++contar;
                }
            }
            if (contar == 2) {
                v[a] = n;
                a++;
            }

        }
    };

    private static Runnable t2 = new Runnable() {
        public synchronized void run() {
            int a = 0;
            int contar = 0;
            for (int k = n/2; k <= n; k++) {
                if (n % k == 0) {
                    ++contar;
                }
            }
            if (contar == 2) {
                v[a] = n;
                a++;
            }        }
    };

}

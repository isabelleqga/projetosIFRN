/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package naoaf;



public class Aluno {
    private String matricula;
    private String nome;
    private int idade;
    private String curso;
    private String turno;
    private int periodo;

    /**
     * @return the matricula
     */
    public String getMatricula() {
        return matricula;
    }

    /**
     * @param matricula the matricula to set
     */
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the curso
     */
    public String getCurso() {
        return curso;
    }

    /**
     * @param curso the curso to set
     */
    public void setCurso(String curso) {
        this.curso = curso;
    }

    /**
     * @return the turno
     */
    public String getTurno() {
        return turno;
    }

    /**
     * @param turno the turno to set
     */
    public void setTurno(String turno) {
        this.turno = turno;
    }

    /**
     * @return the periodo
     */
    public int getPeriodo() {
        return periodo;
    }

    /**
     * @param periodo the periodo to set
     */
    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }
    
    public String gerarJSON() {  
        String produtofinal = "{";
        produtofinal += "\n\"matricula\":\""+getMatricula()+"\",";
        produtofinal += "\n\"nome\":\""+getNome()+"\",";
        produtofinal += "\n\"idade\":"+getIdade()+",";
        produtofinal += "\n\"curso\":\""+getCurso()+"\",";
        produtofinal += "\n\"turno\":\""+getTurno()+"\",";
        produtofinal += "\n\"periodo\":"+getPeriodo();
        produtofinal += "\n}";
        return produtofinal;
	
	   
}
    
    public String gerarXML() {  
        String produtofinal = "<aluno>";
        produtofinal += "\n<matricula>"+getMatricula()+"</matricula>";
        produtofinal += "\n<nome>"+getNome()+"</nome>";
        produtofinal += "\n<idade>"+getIdade()+"</idade>";
        produtofinal += "\n<curso>"+getCurso()+"</curso>";
        produtofinal += "\n<turno>"+getTurno()+"</turno>";
        produtofinal += "\n<periodo>"+getPeriodo()+"</periodo>";
        produtofinal += "\n</aluno>";
        return produtofinal;	   
}
     
}

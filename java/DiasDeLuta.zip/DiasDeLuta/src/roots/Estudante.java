/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class Estudante extends Cidadao{
    private String instituto;
    private String matricula;
    private String periodo;
    private String curso;

    public Estudante() {
        super();
        this.instituto = "IFRN Caicó";
        this.matricula = "20171104010037";
        this.periodo = "Segundo ano";
        this.curso = "Informática";
    }   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class Humor {
    private boolean estresse;   
    private boolean tristeza;  
    private boolean confusao;  
    private boolean desespero;  
    private boolean agonia;  
    private boolean angustia;  
    private boolean ansiedade;  
    private boolean exaustao;  
    private boolean dor;  
    private boolean humilhacao; 
    
    private boolean aceitacao;


    public boolean isEstresse() {
        return estresse;
    }

    public void setEstresse(boolean estresse) {
        this.estresse = true;
    }

    public boolean isTristeza() {
        return tristeza;
    }

    public void setTristeza(boolean tristeza) {
        this.tristeza = true;
    }

    public boolean isConfusao() {
        return confusao;
    }

    public void setConfusao(boolean confusao) {
        this.confusao = true;
    }

    public boolean isDesespero() {
        return desespero;
    }

    public void setDesespero(boolean desespero) {
        this.desespero = true;
    }

    public boolean isAgonia() {
        return agonia;
    }

    public void setAgonia(boolean agonia) {
        this.agonia = true;
    }

    public boolean isAngustia() {
        return angustia;
    }

    public void setAngustia(boolean angustia) {
        this.angustia = true;
    }

    public boolean isAnsiedade() {
        return ansiedade;
    }

    public void setAnsiedade(boolean ansiedade) {
        this.ansiedade = true;
    }

    public boolean isExaustao() {
        return exaustao;
    }

    public void setExaustao(boolean exaustao) {
        this.exaustao = true;
    }

    public boolean isDor() {
        return dor;
    }

    public void setDor(boolean dor) {
        this.dor = true;
    }

    public boolean isHumilhacao() {
        return humilhacao;
    }

    public void setHumilhacao(boolean humilhacao) {
        this.humilhacao = true;
    }

    public boolean isAceitacao() {
        return aceitacao;
    }

    public void setAceitacao(boolean aceitacao) {
        this.aceitacao = aceitacao;
    }
}

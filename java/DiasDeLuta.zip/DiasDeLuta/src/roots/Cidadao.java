/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

public class Cidadao {

    private String nome;
    private int idade;
    private String cpf;
    private String rg;
    private String endereco;
    private String aniversario;
    private String genero;

    public Cidadao() {
        this.nome = "Isabelle Queiroz Gomes de Assis";
        this.idade = 16;
        this.cpf = "0000";
        this.aniversario = "18/12/2001";
        this.rg = "0000";
        this.endereco = "Lua";
        this.genero = "Cryptid";
    }

}

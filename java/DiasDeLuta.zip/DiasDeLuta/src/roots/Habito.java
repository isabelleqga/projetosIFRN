/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class Habito {
    private boolean leitura;
    private boolean dobem;
    private boolean estudar;
    private boolean exercicio;
    private boolean choraranoite;
    private boolean meditacao;
    private boolean jardinagem;

    /**
     * @return the leitura
     */
    public boolean isLeitura() {
        return leitura;
    }

    /**
     * @param leitura the leitura to set
     */
    public void setLeitura(boolean leitura) {
        this.leitura = leitura;
    }

    /**
     * @return the dobem
     */
    public boolean isDobem() {
        return dobem;
    }

    /**
     * @param dobem the dobem to set
     */
    public void setDobem(boolean dobem) {
        this.dobem = dobem;
    }

    /**
     * @return the estudar
     */
    public boolean isEstudar() {
        return estudar;
    }

    /**
     * @param estudar the estudar to set
     */
    public void setEstudar(boolean estudar) {
        this.estudar = estudar;
    }

    /**
     * @return the exercicio
     */
    public boolean isExercicio() {
        return exercicio;
    }

    /**
     * @param exercicio the exercicio to set
     */
    public void setExercicio(boolean exercicio) {
        this.exercicio = exercicio;
    }

    /**
     * @return the choraranoite
     */
    public boolean isChoraranoite() {
        return choraranoite;
    }

    /**
     * @param choraranoite the choraranoite to set
     */
    public void setChoraranoite(boolean choraranoite) {
        this.choraranoite = choraranoite;
    }

    /**
     * @return the meditacao
     */
    public boolean isMeditacao() {
        return meditacao;
    }

    /**
     * @param meditacao the meditacao to set
     */
    public void setMeditacao(boolean meditacao) {
        this.meditacao = meditacao;
    }

    /**
     * @return the jardinagem
     */
    public boolean isJardinagem() {
        return jardinagem;
    }

    /**
     * @param jardinagem the jardinagem to set
     */
    public void setJardinagem(boolean jardinagem) {
        this.jardinagem = jardinagem;
    }
    
    
    
    
    
}

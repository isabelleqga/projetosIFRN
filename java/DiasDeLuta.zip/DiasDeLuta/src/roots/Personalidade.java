/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class Personalidade {
    private String mbti;
    
    public Personalidade(){
        this.mbti="INTJ";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class Relacionamentos {
    private String mae;
    private String pai;
    private String irma;
    private String amigos;
    private String inimigos;
    
    private boolean problema;
    
    public String crs() {
        if (this.problema == true) {
            return ":(";
        } else {
            return ":)";
        }
    }

    public Relacionamentos(){
        this.mae = "Nilvanete";
        this.pai = "Roniere";
        this.irma = "Gabrielle";
        this.problema = true;
        this.amigos = "Dany, Alisson, Arthur, Ywry, Gustavo";
        this.inimigos = "Eudes";
                
    }
    
}

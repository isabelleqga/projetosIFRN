/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class Aparencia {
    
    private double altura;
    private double peso;
    private String descricao;

    public Aparencia(){
        this.altura = 1.71;
        this.peso= 000; //nem sei
        this.descricao = "queria ser uma nuvem";
    }
    
    


    
    
}

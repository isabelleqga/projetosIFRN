/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

public class Vitalidade {
    
    private boolean vivo;
    
    public Vitalidade(){
        this.vivo = true;
    }

    public String vital() {
        if (this.vivo == true) {
            return ":(";
        } else {
            return ":)";
        }
    }
    
    

}

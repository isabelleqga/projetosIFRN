/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roots;

/**
 *
 * @author Isabelle
 */
public class EuInfelizmente extends Estudante{
    private Aparencia aparencia;
    private Personalidade personalidade;
    private Humor humor;
    private Rotina rotina;
    private Vitalidade vitalidade;

    public EuInfelizmente() {
        super();
    }

    public Aparencia getAparencia() {
        return aparencia;
    }

    public void setAparencia(Aparencia aparencia) {
        this.aparencia = aparencia;
    }

    public Personalidade getPersonalidade() {
        return personalidade;
    }

    public void setPersonalidade(Personalidade personalidade) {
        this.personalidade = personalidade;
    }

    public Humor getHumor() {
        return humor;
    }

    public void setHumor(Humor humor) {
        this.humor = humor;
    }

    public Rotina getRotina() {
        return rotina;
    }

    public void setRotina(Rotina rotina) {
        this.rotina = rotina;
    }

    public Vitalidade getVitalidade() {
        return vitalidade;
    }

    public void setVitalidade(Vitalidade vitalidade) {
        this.vitalidade = vitalidade;
    }
    
    
    
    
    
    
}


package main;
import tela.TelaPrincipal;
import entidade.Doenca;
import entidade.Sintoma;
import java.util.ArrayList;

public class Principal {
    
    public static ArrayList<Doenca> lista;
    public static ArrayList<Sintoma> lista1;
    
    public static void main(String args[]){
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
        lista = new ArrayList<>();
        lista1 = new ArrayList<>();
    }
    
}

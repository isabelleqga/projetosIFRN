
package entidade;

public class Doenca {
    
    private String cid;
    private String descricao;
    private String nome;

    public String getCid() {
        return cid;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getNome() {
        return nome;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    
}

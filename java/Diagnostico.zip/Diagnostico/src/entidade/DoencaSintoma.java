
package entidade;

public class DoencaSintoma {
    
    private Doenca doenca;
    private Sintoma sintoma;

    public Doenca getDoenca() {
        return doenca;
    }

    public Sintoma getSintoma() {
        return sintoma;
    }

    public void setDoenca(Doenca doenca) {
        this.doenca = doenca;
    }

    public void setSintoma(Sintoma sintoma) {
        this.sintoma = sintoma;
    }
    
    
    
}

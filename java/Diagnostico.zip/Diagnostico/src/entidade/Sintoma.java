
package entidade;

public class Sintoma {
    
    private String nome;
    private String dor;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getDor() {
        return dor;
    }

    public void setDor(String dor) {
        this.dor = dor;
    }
    
    
    
}

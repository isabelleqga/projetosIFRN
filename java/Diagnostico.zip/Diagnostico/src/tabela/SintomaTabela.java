package tabela;


import entidade.Sintoma;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class SintomaTabela extends AbstractTableModel {

    private ArrayList<Sintoma> lista1;
    private String[] colunas = new String[]{"Sintoma", "Nível de Dor"};

    public SintomaTabela(ArrayList<Sintoma> lista1) {
        this.lista1 = lista1;
    }
 

    @Override
    public int getRowCount() {
        return lista1.size();
    }

    @Override
    public String getColumnName(int column) {
        return colunas[column]; 
    }

    
    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Class<?> getColumnClass(int column) {
        switch (column) {
            case 0:
                return String.class;
            case 1:
                return String.class;
            
            default:
                throw new IndexOutOfBoundsException("column out of bounds");
        }
    }
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Sintoma s = lista1.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return s.getNome();
            case 1:
                return s.getDor();

            default:
                throw new IndexOutOfBoundsException("column out of bounds");
        }
    }
    
    public void delete(int row) {
        lista1.remove(row);
        this.fireTableRowsDeleted(row, row);
    }

    public void add(Sintoma cli) {
        lista1.add(cli);
        this.fireTableRowsInserted(lista1.size() - 1, lista1.size() - 1);
    }

    public Sintoma get(int row) {
        return lista1.get(row);
    }

}

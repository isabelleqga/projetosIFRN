package tabela;


import entidade.Doenca;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class DoencaTabela extends AbstractTableModel {

    private ArrayList<Doenca> lista;
    private String[] colunas = new String[]{"CID", "Nome", "Descrição"};

    public DoencaTabela(ArrayList<Doenca> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public String getColumnName(int column) {
        return colunas[column]; 
    }

    
    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Class<?> getColumnClass(int column) {
        switch (column) {
            case 0:
                return String.class;
            case 1:
                return String.class;
            case 2:
                return String.class;
            
            default:
                throw new IndexOutOfBoundsException("column out of bounds");
        }
    }
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Doenca d = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return d.getCid();
            case 1:
                return d.getNome();
            case 2:
                return d.getDescricao();

            default:
                throw new IndexOutOfBoundsException("column out of bounds");
        }
    }
    
    public void delete(int row) {
        lista.remove(row);
        this.fireTableRowsDeleted(row, row);
    }

    public void add(Doenca cli) {
        lista.add(cli);
        this.fireTableRowsInserted(lista.size() - 1, lista.size() - 1);
    }

    public Doenca get(int row) {
        return lista.get(row);
    }

}

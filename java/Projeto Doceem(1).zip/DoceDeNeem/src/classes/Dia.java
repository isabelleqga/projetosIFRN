/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Isabelle
 */
public class Dia {
    //vai aumentar ou diminuir o numero de pessoas em certo lugar, dependendo da rodada
}
